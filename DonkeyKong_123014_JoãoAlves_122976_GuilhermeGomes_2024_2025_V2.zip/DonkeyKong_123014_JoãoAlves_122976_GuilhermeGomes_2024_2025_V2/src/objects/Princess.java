package objects;

import pt.iscte.poo.utils.Point2D;

public class Princess extends GameElement {

	public Princess(Point2D position) {
		super("Princess", position, 2);
		// TODO Auto-generated constructor stub
	}

}
