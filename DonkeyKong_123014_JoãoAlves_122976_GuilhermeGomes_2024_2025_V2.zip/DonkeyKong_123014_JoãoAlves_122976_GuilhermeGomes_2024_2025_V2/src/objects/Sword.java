package objects;

import pt.iscte.poo.game.Room;
import pt.iscte.poo.gui.ImageGUI;
import pt.iscte.poo.utils.Point2D;

public class Sword extends GameElement implements Items{

	private static final int POWER = 10;
	
	public Sword(Point2D position) {
		super("Sword", position, 2);
		}

	@Override
	public void collect(Room room, Character c) {
		c.modifyPower(POWER);
		room.removeElement(this);
		ImageGUI.getInstance().removeImage(this);
		System.out.println("power jumpman: " + room.getManel().getPower());
	}
	
	@Override
	public int getPower() {
		return POWER;
	}

	@Override
	public int getLife() {
		return 0;
	}


}
