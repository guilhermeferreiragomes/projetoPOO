package objects;

import pt.iscte.poo.game.GameEngine;
import pt.iscte.poo.game.Room;
import pt.iscte.poo.gui.ImageGUI;
import pt.iscte.poo.utils.Direction;
import pt.iscte.poo.utils.Point2D;

public class DonkeyKong extends GameElement implements Enemy  {

	private Point2D position;
	private int life;
	private static final int POWER = 30;
	private Direction currentDirection;
	
	public DonkeyKong(Point2D position) {
		super("DonkeyKong", position, 2);
		this.life = 100;
		this.currentDirection = Direction.RIGHT;
	}
	
	@Override
	public void enemyMove(Room room) {
		Direction dir = Direction.random();
		position = getPosition().plus(dir.asVector());
		GameElement block = room.getElement(position);
		if(room.isValidMove(position) && dir != Direction.DOWN && !(room.getElement(position) instanceof DoorClosed) && !(room.getElement(position) instanceof Princess)) {
			if(block instanceof Character) {
				Character c = (Character) block;
				attack(c);
			}
			if(block instanceof DonkeyKong) {
				DonkeyKong dk = (DonkeyKong) block;
				attackOwn(dk);
				die(room);
			}
		setPosition(position);
		setCurrentDirection(dir);
		updateImg();

		}
	}

	@Override
	public void attack(Character c) {
		c.modifyLife(-POWER);
	}
	
	@Override
	public void die(Room room) {
		if(this.life <= 0) {
			room.removeElement(this);
			ImageGUI.getInstance().removeImage(this);
		}
	}
	
	public void launchBanana(Room room) {
        int ticks = ImageGUI.getInstance().getTicks();
        Point2D positionBelow = getPosition().plus(Direction.DOWN.asVector());
        Banana banana = new Banana(positionBelow);
        if (ticks % 3 == 0) {
            room.addElement(banana); // Adiciona a banana à lista de elementos da sala
            ImageGUI.getInstance().addImage(banana); // Mostra a banana na interface gráfica
        }
    }




	@Override
	public void modifyLife(int amount) {
		this.life += amount;
	}

	@Override
	public int getLife() {
		return this.life;
	}

	@Override
	public int getPower() {
		return this.POWER;
	}

	@Override
	public void setLife(int amount) {
		this.life = amount;
	}

	public void setCurrentDirection(Direction dir) {
		this.currentDirection = dir;
	}

	public void attackOwn(DonkeyKong dk) {
		dk.modifyLife(-POWER);
	}

	public void updateImg() {
		if(currentDirection == Direction.RIGHT) {
			setName("DonkeyKong");
		} else {
			setName("DonkeyKongInverted");
		}
	}	

}
