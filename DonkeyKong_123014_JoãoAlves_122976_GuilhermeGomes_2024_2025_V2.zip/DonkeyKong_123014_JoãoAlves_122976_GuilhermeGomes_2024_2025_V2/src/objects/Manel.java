package objects;

import pt.iscte.poo.gui.ImageGUI;

import java.util.ArrayList;
import java.util.List;

import pt.iscte.poo.game.GameEngine;
import pt.iscte.poo.game.Room;
import pt.iscte.poo.utils.Direction;
import pt.iscte.poo.utils.Point2D;

public class Manel extends GameElement implements Character {

	private Point2D position;
	private int power;
	private int life;
	private List<String> inventory = new ArrayList<>();
	private Direction currentDirection;
	private int lives;
	
	public Manel(Point2D initialPosition) {
		super("JumpMan", initialPosition, 2);
		this.life = 100;
		this.power = 20;
		this.lives = 3;
		this.currentDirection = Direction.RIGHT;
	}

	public void move(Direction dir, Room room) {
		position = getPosition().plus(dir.asVector());
		GameElement block = room.getElement(position);
		
		if (block instanceof Enemy) {
			Enemy e = (Enemy) block;
			if (block instanceof Bat) {
				e.attack(this);
			}
			attack(e);
			e.die(room);
		}
		setPosition(position);
		setCurrentDirection(dir);
		updateImg();
	}
	
	
	public void dropBomb(Bomb bomb, Room room) {
	    if (hasItem("Bomb")) { // Verifica se o Manel tem uma bomba
	        bomb.activate(); // Ativa a bomba
	        bomb.setPosition(getPosition()); // Define a posição da bomba
	        room.addElement(bomb); 
	        ImageGUI.getInstance().addImage(bomb); 
	        removeItem("Bomb"); // Remove a bomba do inventário do Mane
		}
	}
	
	@Override
	public void attack(Enemy e) {
		e.modifyLife(-power);
	}
	
	@Override
	public void modifyLife(int amount) {
		this.life += amount;
	}
	
	@Override
	public void modifyPower(int amount) {
		this.power += amount;
	}
	
	public void addItem(String element) {
		inventory.add(element);
	}

	public void clearInventory() {
		inventory.clear();
	}
	
	public void removeItem(String element) {
		inventory.remove(element);
	}
	
	/////////////////////////////////// GETTERS ///////////////////////////////////
	
	@Override
	public int getLife() {
		return this.life;
	}
	
	public int getPower() {
		return this.power;
	}

	public int getLives() {
		return this.lives;
	}

	public Direction getCurrentDirection() {
		return this.currentDirection;
	}
	
	public List<String> getInventory() {
		return inventory;
	}

	//////////////////////////////////// SETTERS ///////////////////////////////////
	
	@Override
	public void setPower(int amount) {
		this.power = amount;
	}
	
	@Override
	public void setLife(int amount) {
		this.life = amount;
	}

	public Direction setCurrentDirection(Direction dir) {
		return this.currentDirection = dir;
	}

	public void setLives(int amount) {
		this.lives = amount;
	}

	/////////////////////////////// VALIDATORS ///////////////////////
	
	public boolean hasItem(String element) {
		return inventory.contains(element);
	}

	public void updateImg() {
	    String nickname = GameEngine.getInstance().getNickname();

	    // Prioridade: Nicknames especiais
	    if (nickname.equals("Joao")) {
			
	        setName("Gui");
	        return; 
	    } 
	    if (nickname.equals("Jose")) {
	        setName("Skeleton");
	        return; // Sai do método
	    }

		if(nickname.equals("Gui")) {
			setName("Chill");
			return;
		}
		
	    if (getCurrentDirection() != null) { 
	        if (getCurrentDirection().equals(Direction.RIGHT)) {
	            setName("JumpMan");
	        } else if (getCurrentDirection().equals(Direction.LEFT)) {
	            setName("JumpManInverted");
	        }
	    } else {
	        setName("JumpMan");
	    }
	}

}
