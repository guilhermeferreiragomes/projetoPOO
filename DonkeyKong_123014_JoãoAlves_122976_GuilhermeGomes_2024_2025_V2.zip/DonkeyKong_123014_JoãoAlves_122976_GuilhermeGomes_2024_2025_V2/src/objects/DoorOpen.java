package objects;

import pt.iscte.poo.utils.Point2D;

public class DoorOpen extends GameElement {

	public DoorOpen(Point2D position) {
		super("DoorOpen", position, 2);
		// TODO Auto-generated constructor stub
	}

}
