package objects;

import pt.iscte.poo.game.Room;
import pt.iscte.poo.utils.Point2D;

public interface Enemy {

	public void attack(Character c);
	public void setLife(int amount);
	public void modifyLife(int amount);
	public int getLife();
	public void die(Room room);
	public int getPower();
	public void enemyMove(Room room);
	public Point2D getPosition();
	
}
