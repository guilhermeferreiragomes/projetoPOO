package objects;

import pt.iscte.poo.game.Room;
import pt.iscte.poo.gui.ImageGUI;
import pt.iscte.poo.utils.Direction;
import pt.iscte.poo.utils.Point2D;

public class Spider extends GameElement implements Enemy {

    private int life;
    private int power;
    private Point2D position;
    private Direction currentDirection;

    
    public Spider(Point2D position) {
        super("Spider", position, 2); // Nome da Banana, posição e ID (3 por exemplo)
		this.life = 100;
		this.power = 15;
        this.currentDirection = Direction.RIGHT;


	}

	public void enemyMove(Room room) {
            Direction dir = Direction.random();
            position = getPosition().plus(dir.asVector());
            GameElement block = room.getElement(position);
            if(room.isValidMove(position) && dir != Direction.DOWN && dir != Direction.UP) {
                if(block instanceof Character) {
                    Character c = (Character) block;
                    attack(c);
                }
            setPosition(position);
            setCurrentDirection(dir);
            updateImg();
            }
        }
	
	@Override
	public void attack(Character c) {
		c.modifyLife(-power);
	}
	
	@Override
	public void die(Room room) {
		room.removeElement(this);
		ImageGUI.getInstance().removeImage(this);
	}

	@Override
	public void modifyLife(int amount) {
		this.life += amount;	
	}

	@Override
	public int getLife() {
		return this.life;
	}

	@Override
	public int getPower() {
		return this.getPower();
	}

	@Override
	public void setLife(int amount) {
		this.life = amount;
	}

    public void setCurrentDirection(Direction dir) {
		this.currentDirection = dir;
	}

	
	public void updateImg() {
        if(currentDirection == Direction.LEFT) {
			setName("Spider");
		} else {
			setName("SpiderInverted");
		}
	}

}


