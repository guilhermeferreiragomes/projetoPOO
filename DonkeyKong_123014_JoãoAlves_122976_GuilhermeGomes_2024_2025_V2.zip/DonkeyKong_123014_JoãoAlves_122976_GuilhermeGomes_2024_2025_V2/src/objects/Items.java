package objects;

import pt.iscte.poo.game.Room;

public interface Items {

	public void collect(Room room, Character c);
	public int getPower();
	public int getLife();
	
}
