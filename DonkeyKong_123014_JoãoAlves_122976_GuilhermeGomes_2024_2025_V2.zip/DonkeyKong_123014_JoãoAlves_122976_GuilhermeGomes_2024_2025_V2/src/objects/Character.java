package objects;

public interface Character {

	public void attack(Enemy e);
	public void setLife(int amount);
	public void setPower(int amount);
	public int getLife();
	public void modifyLife(int amount);
	public void modifyPower(int amount);
	
}
