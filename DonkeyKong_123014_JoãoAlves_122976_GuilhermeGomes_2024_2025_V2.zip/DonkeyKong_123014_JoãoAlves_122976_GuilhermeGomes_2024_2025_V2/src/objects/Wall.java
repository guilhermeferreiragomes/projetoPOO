package objects;

import pt.iscte.poo.utils.Point2D;

public class Wall extends GameElement implements Intransposable {

	public Wall(Point2D position) {
		super("Wall", position, 1);
		// TODO Auto-generated constructor stub
	}
	
}
