package objects;

import pt.iscte.poo.gui.ImageTile;
import pt.iscte.poo.utils.Point2D;

public abstract class GameElement implements ImageTile {
    private String name;
    private int layer;
    private Point2D position;
    

    public GameElement(String name, Point2D position, int layer) {
        this.name = name;
        this.layer = layer;
        this.position = position;
    }

    // GETTERS
    @Override
    public String getName() {
        return name;
    }

    @Override
    public int getLayer() {
        return layer;
    }

    @Override
    public Point2D getPosition() {
        return position;
    }


    // SETTERS
    public void setPosition(Point2D position) {
        this.position = position;
    }

    public void setName(String name) {
        this.name = name;
    }

    

    public static GameElement createGameElement(char c, Point2D position) {
        switch (c) {
            case 'W':
                return new Wall(position);
            case 'P':
                return new Princess(position);
            case 'g':
                return new GoodMeat(position);
            case 'S':
                return new Stairs(position);
            case 's':
                return new Sword(position);
            case 'T':
                return new Trap(position);
            case ' ':
                return new Floor(position);
            case 'G':
                return new DonkeyKong(position);
            case 't':
                return new Trap(position);
            case '0':
                return new DoorClosed(position);
            case 'H':
                return null;
            case '1':
                return new DoorOpen(position);
            case 'K':
                return new Key(position);
            case 'b':
                return new Bat(position);
            case 'z':
                return new Bomb(position);
            case 'c':
                return new HiddenTrap(position);
            case 'f':
                return new Teleport(position);
            case 'a':
                return new GoldenApple(position);
            case 'o': 
                return new Spider(position);
        }

                throw new IllegalArgumentException("Caractere desconhecido: " + c);
    }

}
	


    

