package objects;

import pt.iscte.poo.game.Room;
import pt.iscte.poo.gui.ImageGUI;
import pt.iscte.poo.utils.Point2D;

public class HiddenTrap extends GameElement implements Intransposable, Traps {
	
    static final int DAMAGE = 10; 

    public HiddenTrap(Point2D position) {
        super("Wall", position, 1); // Inicialmente parece uma parede
    }

    @Override
	public void damage(Room room) {
    	setName("Trap");
    	ImageGUI.getInstance().update();
		room.getManel().modifyLife(-DAMAGE);
	}

}