package objects;

import pt.iscte.poo.utils.Point2D;

public class DoorClosed extends GameElement {

	public DoorClosed(Point2D position) {
		super("DoorClosed", position, 1);
		// TODO Auto-generated constructor stub
	}
}
