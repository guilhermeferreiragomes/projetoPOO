
package objects;

import pt.iscte.poo.game.Room;
import pt.iscte.poo.gui.ImageGUI;
import pt.iscte.poo.utils.Point2D;

public class Bomb extends GameElement implements Items {
    private int startTick = -1; // Tick inicial quando a bomba foi ativada
    private boolean activated = false; // Define se a bomba foi dropada e está ativa

    public Bomb(Point2D position) {
        super("Bomb", position, 2);
    }

    @Override
    public void collect(Room room, Character c) {
        room.getManel().addItem("Bomb"); // Adiciona a bomba ao inventário do Manel
        room.removeElement(this); // Remove do ambiente
        ImageGUI.getInstance().removeImage(this);
    }

    @Override
    public int getPower() {
        return 0;
    }

    @Override
    public int getLife() {
        return 0;
    }

    public boolean isIntransposable() {
        return activated;
    }

    // Método para ativar a bomba
    public void activate() {
        if (!activated) {
            this.startTick = ImageGUI.getInstance().getTicks(); // Armazena o tick inicial
            this.activated = true;
            System.out.println("Bomba ativada no tick: " + startTick);
        }
    }

    public void checkExplosion(Room room) {
        int currentTick = ImageGUI.getInstance().getTicks();

        // Explosão automática após 5 ticks
        if (activated && currentTick - startTick >= 5) {
            explode(room);
            return;
        }
    }

    // Lógica da explosão
    public void explode(Room room) {
        System.out.println("BOOM! Bomba explodiu no tick: " + ImageGUI.getInstance().getTicks());

        // Remove a bomba do jogo
        room.removeElement(this);
        ImageGUI.getInstance().removeImage(this);

        Point2D position = getPosition();
        for (int x = -1; x <= 1; x++) {
            for (int y = -1; y <= 1; y++) {
                Point2D affectedPosition = new Point2D(position.getX() + x, position.getY() + y);
                GameElement element = room.getElement(affectedPosition);

                if (element instanceof Items || element instanceof Enemy) {
                    if (element instanceof Character) {
                        ((Character) element).modifyLife(-100);
                    }

                    room.removeElement(element);
                    ImageGUI.getInstance().removeImage(element);
                }
            }
        }
    }

}