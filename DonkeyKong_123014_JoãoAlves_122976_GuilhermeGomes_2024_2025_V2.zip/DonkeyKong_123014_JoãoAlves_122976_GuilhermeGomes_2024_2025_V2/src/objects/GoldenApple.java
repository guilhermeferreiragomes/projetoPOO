package objects;

import pt.iscte.poo.game.Room;
import pt.iscte.poo.gui.ImageGUI;
import pt.iscte.poo.utils.Point2D;

public class GoldenApple extends GameElement implements Items {

	private static final int POWER = 60;
    private static final int LIFE = 150;

    public GoldenApple(Point2D position) {
        super("GoldenApple", position, 2);
    }



    @Override
    public void collect(Room room, Character c) {
        c.modifyPower(POWER);
        c.modifyLife(LIFE);
        room.removeElement(this);
        ImageGUI.getInstance().removeImage(this);
    }

    @Override
    public int getPower() {
        return POWER;
    }

    @Override
    public int getLife() {
        return LIFE;
    }

}
