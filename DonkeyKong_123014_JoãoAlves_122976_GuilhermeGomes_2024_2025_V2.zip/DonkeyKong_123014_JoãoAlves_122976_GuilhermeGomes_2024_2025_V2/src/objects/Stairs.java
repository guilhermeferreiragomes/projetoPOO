package objects;

import pt.iscte.poo.utils.Point2D;

public class Stairs extends GameElement {

	public Stairs(Point2D position) {
		super("Stairs", position, 0);
		// TODO Auto-generated constructor stub
	}


}
