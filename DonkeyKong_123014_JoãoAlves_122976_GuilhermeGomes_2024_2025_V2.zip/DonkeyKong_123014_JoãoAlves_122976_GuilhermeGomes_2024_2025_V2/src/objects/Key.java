package objects;

import pt.iscte.poo.game.Room;
import pt.iscte.poo.gui.ImageGUI;
import pt.iscte.poo.utils.Point2D;

public class Key extends GameElement implements Items {

	public Key(Point2D position) {
		super("Key", position, 2);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void collect(Room room, Character c) {
		room.removeElement(this);
		ImageGUI.getInstance().removeImage(this);
	}

	@Override
	public int getPower() {
		return 0;
	}

	@Override
	public int getLife() {
		return 0;
	}

	
}
