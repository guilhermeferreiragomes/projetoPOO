package objects;

import pt.iscte.poo.game.Room;
import pt.iscte.poo.gui.ImageGUI;
import pt.iscte.poo.utils.Direction;
import pt.iscte.poo.utils.Point2D;

public class Banana extends GameElement implements Items {

    public Banana(Point2D position) {
        super("Banana", position, 3);
    }
    
    // Método para a banana cair
	public void moveDown(Room room) {
		Point2D newPosition = getPosition().plus(Direction.DOWN.asVector());
		Point2D manelPosition = room.getManel().getPosition();
		
		if (newPosition.equals(manelPosition)) { // Se a banana cair sobre o Manel
			collect(room, room.getManel()); // Coleta a banana (fazendo-a desaparecer)
		} else {
			setPosition(newPosition); // Move a banana para a nova posição
		}
	}
	

    @Override
    public void collect(Room room, Character c) {
		c.modifyLife(-100);
        room.removeElement(this); 
        ImageGUI.getInstance().removeImage(this); 
		System.out.println("levei com a banana");

    }


    @Override
    public int getPower() {
        return 0;
    }

    @Override
    public int getLife() {
        return 0;
    }
}
