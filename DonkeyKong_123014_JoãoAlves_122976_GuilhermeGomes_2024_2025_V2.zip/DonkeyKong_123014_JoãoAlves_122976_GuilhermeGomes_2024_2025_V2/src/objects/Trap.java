package objects;

import pt.iscte.poo.game.Room;
import pt.iscte.poo.utils.Point2D;

public class Trap extends GameElement implements Traps{

	static final int DAMAGE = 10; 
	
	public Trap(Point2D position) {
		super("Trap", position, 1);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void damage(Room room) {
		GameElement block = room.getElement(getPosition());
		if(block instanceof Trap) {
			room.getManel().modifyLife(-DAMAGE);
		}
	}

}
