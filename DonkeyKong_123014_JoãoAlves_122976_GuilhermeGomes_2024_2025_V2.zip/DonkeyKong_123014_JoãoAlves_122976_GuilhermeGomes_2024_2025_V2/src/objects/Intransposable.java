package objects;

public interface Intransposable {

}
