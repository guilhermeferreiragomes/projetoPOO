package objects;

import pt.iscte.poo.game.Room;

public interface Traps {

	public void damage(Room room);
	
}
