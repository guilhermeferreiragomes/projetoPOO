package objects;

import pt.iscte.poo.utils.Point2D;

public class Floor extends GameElement{

	public Floor(Point2D position) {
		super("Floor", position, 0);
		// TODO Auto-generated constructor stub
	}

}
