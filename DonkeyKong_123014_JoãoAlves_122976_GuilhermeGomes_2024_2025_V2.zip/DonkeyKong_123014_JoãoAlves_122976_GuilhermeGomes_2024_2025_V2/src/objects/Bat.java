package objects;

import pt.iscte.poo.game.Room;
import pt.iscte.poo.gui.ImageGUI;
import pt.iscte.poo.utils.Direction;
import pt.iscte.poo.utils.Point2D;

public class Bat extends GameElement implements Enemy {

	private int life;
	private int power;
	private Point2D position;
	
	public Bat(Point2D position) {
		super("Bat", position, 2);
		this.life = 100;
		this.power = 15;
	}

	public void enemyMove(Room room) {
		Direction dir = Direction.random();
		position = getPosition().plus(dir.asVector());
		GameElement block = room.getElement(position);
		GameElement blockBelow = room.getElement(position.plus(Direction.DOWN.asVector()));
		if(room.isValidMove(position) && dir != Direction.UP) {
			if(blockBelow instanceof Stairs) {
				setPosition(position.plus(Direction.DOWN.asVector()));
			}
			if(block instanceof Character) {
				Character c = (Character) block;
				attack(c);
				die(room);
			}
			setPosition(position);
		}
	}
	
	@Override
	public void attack(Character c) {
		c.modifyLife(-power);
	}
	
	@Override
	public void die(Room room) {
		room.removeElement(this);
		ImageGUI.getInstance().removeImage(this);
	}

	@Override
	public void modifyLife(int amount) {
		this.life += amount;	
	}

	@Override
	public int getLife() {
		return this.life;
	}

	@Override
	public int getPower() {
		return this.getPower();
	}

	@Override
	public void setLife(int amount) {
		this.life = amount;
	}



}
