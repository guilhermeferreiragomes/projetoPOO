package objects;

import pt.iscte.poo.game.Room;
import pt.iscte.poo.utils.Direction;
import pt.iscte.poo.utils.Point2D;

public class Teleport extends GameElement implements Items {

    public Teleport(Point2D position) {
        super("Teleport", position, 1);
    }

    @Override
    public void collect(Room room, Character c) {
        if (c instanceof Manel) {
            Manel manel = (Manel) c;
            Point2D currentPosition = manel.getPosition();
            int x = 0;

            // Verifica a direção e ajusta o movimento para a direita ou esquerda
            if (manel.getCurrentDirection() == Direction.RIGHT) {
                x = 5; // Move 5 casas para a direita
            } else if (manel.getCurrentDirection() == Direction.LEFT) {
                x = -5; // Move 5 casas para a esquerda
            }

            // IMPEDIR QUE MANEL PASSE DOS LIMITES COM o Teleport
            int newX = currentPosition.getX() + x;
            
            if (newX < 0) {
                newX = 1; // Não pode passar do limite esquerdo
            } else if (newX > room.GRID_MEASURE) {
                newX = room.GRID_MEASURE - 2; // Não pode passar do limite direito
            }

            Point2D newPosition = new Point2D(newX, currentPosition.getY());
            manel.setPosition(newPosition);  // Atualiza a posição do Manel
        }
    }

    @Override
    public int getPower() {
        return 0;
    }

    @Override
    public int getLife() {
        return 0;
    }
}
