package objects;

import pt.iscte.poo.game.Room;
import pt.iscte.poo.gui.ImageGUI;
import pt.iscte.poo.utils.Point2D;

public class GoodMeat extends GameElement implements Items {

    public static final int VIDA = 10;
	
		public GoodMeat(Point2D position) {
			super("GoodMeat", position, 2);
		}
	
		@Override
		public void collect(Room room, Character c) {
			if (getName().equals("GoodMeat")) {
				c.modifyLife(VIDA);            // Aumenta a vida do personagem
				room.removeElement(this);
				ImageGUI.getInstance().removeImage(this);
			}
			else if(getName().equals("BadMeat")) {
				c.modifyLife(-VIDA);            // Aumenta a vida do personagem
				room.removeElement(this);
				ImageGUI.getInstance().removeImage(this);
			}
		}

    @Override
    public int getPower() {
        return 0;
    }

    @Override
    public int getLife() {
        return VIDA;
    }
}
