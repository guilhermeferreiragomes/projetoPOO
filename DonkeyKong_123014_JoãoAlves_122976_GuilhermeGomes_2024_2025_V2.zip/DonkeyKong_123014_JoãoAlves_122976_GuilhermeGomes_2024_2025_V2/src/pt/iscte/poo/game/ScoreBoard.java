package pt.iscte.poo.game;

import java.io.*;
import java.util.*;

import pt.iscte.poo.gui.ImageGUI;

public class ScoreBoard {
    private static final String FILE_NAME = "scores.txt"; // Nome do arquivo de pontuação
    private List<Score> scores;

    public ScoreBoard() {
        scores = new ArrayList<>();
        loadScores();  // Carregar pontuações ao iniciar
    }

    private void loadScores() {
        try (Scanner scanner = new Scanner(new File(FILE_NAME))) {
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                String[] division = line.split(",");
                if (division.length == 2) {
                    String nickname = division[0];
                    int ticks = Integer.parseInt(division[1]);
                    scores.add(new Score(nickname, ticks));
                }
            }
        } catch (IOException e) {
            System.out.println("Erro ao carregar pontuações: " + e.getMessage());
        }
    }


    private void saveScores() {
        try (PrintWriter writer = new PrintWriter(new File(FILE_NAME))) {
            for (Score score : scores) {
                writer.println(score.getNickname() + "," + score.getTicks());
            }
        } catch (IOException e) {
            System.out.println("Erro " + e.getMessage());
        }
    }


    // Adicionar um novo resultado e manter apenas os 5 melhores
    public void addScore(String nickname, int ticks) {
        Score newScore = new Score(nickname, ticks);
        scores.add(newScore);
        // Ordenar a lista por ticks (menor primeiro)
        scores.sort(Comparator.comparingInt(Score::getTicks));
        // Manter apenas os 5 melhores
        if (scores.size() > 5) {
            scores.remove(scores.size() - 1);  // Remove o pior
        }
        saveScores(); 
    }

    public List<Score> getScores() {
        return scores;
    }

    public void displayScores() {
		StringBuilder scoresMessage = new StringBuilder("TOP 5 JOGADORES:\n");
		for (Score score : scores) {
			scoresMessage.append(score.getNickname())
						 .append(" - ")
						 .append(score.getTicks())
						 .append(" ticks\n");
		}

		ImageGUI.getInstance().showMessage("Maiores do bairro:", scoresMessage.toString(), null);
	}

    public void clearScores() {
        scores.clear(); 

            File file = new File(FILE_NAME);
        if (file.exists()) {
            file.delete(); 
        }
    }



}
