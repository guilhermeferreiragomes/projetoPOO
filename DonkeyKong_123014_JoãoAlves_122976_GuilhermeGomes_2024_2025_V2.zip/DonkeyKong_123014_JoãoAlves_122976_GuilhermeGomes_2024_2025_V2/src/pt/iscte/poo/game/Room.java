package pt.iscte.poo.game;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import objects.Banana;
import objects.Bomb;
import objects.Character;
import objects.DonkeyKong;
import objects.DoorClosed;
import objects.DoorOpen;
import objects.Enemy;
import objects.Floor;
import objects.GameElement;
import objects.GoodMeat;
import objects.HiddenTrap;
import objects.Intransposable;
import objects.Items;
import objects.Key;
import objects.Manel;
import objects.Princess;
import objects.Traps;
import pt.iscte.poo.gui.ImageGUI;
import pt.iscte.poo.utils.Direction;
import pt.iscte.poo.utils.Point2D;

public class Room {
	
	private Point2D heroStartingPosition;
	private Manel manel;
	public final int GRID_MEASURE = 10;
	private int level = 0;
	private List<GameElement> elementList = new ArrayList<>();
	private int roomTickCount = 0; // Counter de ticks da sala atual
	private int currentTicks;
	private int startingTicks;
	
	public Room() {
		loadRoom(level);
		manel = new Manel(heroStartingPosition);
		ImageGUI.getInstance().addImage(manel);
		this.currentTicks = ImageGUI.getInstance().getTicks();
	}

	public void loadRoom(int level) {
		background();
		boolean fileLoaded = loadRoomFromFile("rooms/room" + level + ".txt");
	
		if (!fileLoaded) {
			Scanner input = new Scanner(System.in);
			System.out.print("Room não existe. Qual o número do nível que queres jogar?:\n");
			String fileName = "rooms/room" + input.nextLine() + ".txt";
			loadRoomFromFile(fileName);
		}
	}
	
	private boolean loadRoomFromFile(String fileName) {
		try {
			File f = new File(fileName);
			Scanner scanner = new Scanner(f);
			int y = 0; // linha do mapa
			scanner.nextLine();
	
			while (scanner.hasNextLine()) {
				String line = scanner.nextLine();
				char[] dadosLine = line.toCharArray();
	
				for (int x = 0; x < dadosLine.length; x++) {
					char c = dadosLine[x];
					Point2D position = new Point2D(x, y);
					try {
						if (c == 'H') {
							// Armazena a posição do Manel
							heroStartingPosition = position;
						} else if (c != ' ') { // Como já temos função background, não precisamos de criar o chão duas vezes
							GameElement element = GameElement.createGameElement(c, position);
							elementList.add(element);
							ImageGUI.getInstance().addImage(element);
						}
					} catch (IllegalArgumentException e) {
						System.err.println(e.getMessage());
					}
				}
				y++; // Incrementa a linha após processar todos os caracteres da linha atual
			}
			scanner.close();
			ImageGUI.getInstance().update(); // Atualiza a interface gráfica após adicionar todos os elementos
			return true;
		} catch (FileNotFoundException e) {
			System.err.println("Arquivo não encontrado: " + fileName);
			return false;
		}
	}


	public void background() {
		for (int y = 0; y < GRID_MEASURE; y++) {
			for (int x = 0; x < GRID_MEASURE; x++) {
				ImageGUI.getInstance().addImage(new Floor(new Point2D(x, y)));
			}
		}
	}

	
	public void manelStuff(Direction dir) {
		Point2D newPosition = manel.getPosition().plus(dir.asVector());
		GameElement block = getElement(newPosition);
		
		if(isValidMove(newPosition)) {
			
			interactsWith(block);

			manel.move(dir, this);
			
	        GameElement blockBelow = getElement(manel.getPosition().plus(Direction.DOWN.asVector()));
	        if (blockBelow instanceof Traps) {
	            Traps t = (Traps) blockBelow;
	            t.damage(this);
	        } else if(elementList.contains(getHT())) {
	        	getHT().setName("Wall");
	        }
			
			while (!isBlockBelow(manel.getPosition())) {
				Point2D below = manel.getPosition().plus(Direction.DOWN.asVector());
				try {
					Thread.sleep(100); // Adiciona um pequeno atraso para simular a queda
				} catch (InterruptedException e) {
					Thread.currentThread().interrupt(); // Retoma o estado de interrupção da thread
				}
				manel.setPosition(below); // Atualiza a posição para baixo
				ImageGUI.getInstance().update(); // Atualiza a interface gráfica para mostrar o movimento
			}
		}
	}


	public boolean win() {
		// Verifica os arredores da posição atual do Manel
		for (Direction dir : Direction.values()) {
			Point2D newPosition = manel.getPosition().plus(dir.asVector());
			GameElement block = getElement(newPosition);
			if (block instanceof Princess) {
				return true;
			}
		}
		return false;
	}
	
	
	public void interactsWith(GameElement element) {
		//Interação com items
		if(element instanceof Items) {
			Items item = (Items) element;
			
			if(element instanceof Key) {
				manel.addItem("Key");
			}
			
			item.collect(this, manel);
		}	
		
		//Interação com as portas
		if(element instanceof DoorClosed) {
			if(!manel.hasItem("Key")) {
				ImageGUI.getInstance().showMessage("Porta trancada!", "Precisas de uma\nchave para passar", "images\\Valentim.jpg");
			} else {
				nextLevel();
				return;
			}
		} 
		if(element instanceof DoorOpen) {
			nextLevel();
		}
	}
	

	public void enemyStuff() {
		List<GameElement> elementsCopy = new ArrayList<>(elementList);
		for(GameElement element : elementsCopy) {
			if(element instanceof Enemy) {
				Enemy e = (Enemy) element;
				if(isValidMove(e.getPosition().plus(Direction.random().asVector()))) {
					e.enemyMove(this);
				}
				
				if(element instanceof DonkeyKong) {
					DonkeyKong dk = (DonkeyKong) element;
					dk.launchBanana(this);
				}
			}
			if (element instanceof Banana) {
				((Banana) element).moveDown(this); // Faz a banana cair
			}
		}
		ImageGUI.getInstance().update();
	}

	public void badMeat() {
		roomTickCount++;
	
		if (roomTickCount >= 70) { // Quando atingir70 ticks passa para BadMeat
			for (GameElement element : elementList) {
				if (element instanceof GoodMeat) {
					// Altera o nome de GoodMeat para BadMeat
					element.setName("BadMeat");
				}
			}
		}
	}


	
	
	void nextLevel() {
		level++; // Passa para o próximo nível
		manel.clearInventory(); // Limpa o inventário do Manel
		elementList.clear(); // Limpa a lista de elementos
		ImageGUI.getInstance().clearImages(); // Limpa as imagens da GUI
		loadRoom(level); // Carrega o próximo mapa
		manel.setPosition(heroStartingPosition); // Coloca o Manel na posição inicial do novo nível
		ImageGUI.getInstance().addImage(manel); // Re-adiciona o Manel à interface gráfica
		roomTickCount = 0; // Reinicia o contador de ticks
	}
	
	public void resetGame() {
		level = 0; // Reinicia o nível
		elementList.clear(); // Limpa a lista de elementos
		ImageGUI.getInstance().clearImages(); // Limpa as imagens da GUI
		loadRoom(level); // Carrega o primeiro mapa
		manel.setPosition(heroStartingPosition); // Coloca o Manel na posição inicial
		ImageGUI.getInstance().addImage(manel); // Adiciona o Manel à interface gráfica
		manel.setLife(100);
		manel.setPower(20);
		manel.clearInventory();
		manel.setLives(3);
	}
	
	///////////////////////////// BOMBA ////////////////////////////////////////
	
	public void explode(Bomb b) {
		removeElement(b);
        ImageGUI.getInstance().removeImage(b);

        // Lógica para danificar elementos na área de explosão
        Point2D position = manel.getPosition();
        for (int x = -1; x <= 1; x++) {
            for (int y = -1; y <= 1; y++) {
            	Point2D affectedPosition = new Point2D(position.getX() + x, position.getY() + y);
                GameElement element = getElement(affectedPosition);
                if (!(element instanceof Intransposable)) {
                    removeElement(element);
                    ImageGUI.getInstance().removeImage(element);
                    if (element instanceof Character) {
                        ((Character) element).setLife(-100);
                    }
                }
            }
        }
	}
	
	public void explosion(Bomb b) {
		if(currentTicks - startingTicks == 0) {
			explode(b);
		}
	}
	
	//////////////////////////// LISTA ////////////////////////////////////////
	
	public void removeElement(GameElement element) {
			elementList.remove(element);
	}
	
	public void addElement(GameElement element) {
		elementList.add(element);
	}
	
	public boolean hasElement(GameElement element) {
		return elementList.contains(element);
	}
	
	//////////////////////////// VALIDATORS ////////////////////////////////
	
	public boolean isValidMove(Point2D newPosition) {
	    GameElement block = getElement(newPosition);

	    if (block instanceof Bomb && ((Bomb) block).isIntransposable()) {
	    	((Bomb) block).explode(this);
	    	manel.modifyLife(-100);
	        return false; // Movimento inválido se a bomba é Intransposable
	    }

	    // Verifica se o bloco é Intransposable
	    if (block != null && block instanceof Intransposable) {
	        return false;
	    }

	    // Verifica se está dentro dos limites da sala
	    return newPosition.getX() >= 0 && newPosition.getX() < 10 && newPosition.getY() >= 0 && newPosition.getY() < 10;
	}

	boolean isDoorOpen(Point2D position) {
		GameElement element = getElement(position);
		return element instanceof DoorOpen;
	}

	boolean isDoorClosed(Point2D position) {
		GameElement element = getElement(position);
		return element instanceof DoorClosed;
	}
	
	public boolean isBlockBelow(Point2D position) {
		Point2D below = position.plus(Direction.DOWN.asVector()); // Posição imediatamente abaixo
		GameElement blockBelow = getElement(below);

		if (blockBelow != null) {
			return !(blockBelow instanceof Floor);
		}
		return false; // Não há nenhum bloco abaixo
	}

	
	//////////////////////////// GETTERS //////////////////////////////////
	
	public GameElement getElement(Point2D position) {
		if(position.equals(getManel().getPosition())) {
			return getManel();
		}
		for (GameElement element : elementList) {
			if (element != null && element.getPosition().equals(position)) { 
				return element;
			}
		}
		return null; // Retorna null se nenhum elemento for encontrado
	}
	
	public Manel getManel() {
		return manel;
	}

	public Point2D getHeroStartingPosition() {
		return heroStartingPosition;
	}

	public HiddenTrap getHT() {
		List<GameElement> elementsCopy = new ArrayList<>(elementList);
		for(GameElement element : elementsCopy) {
			if(element instanceof HiddenTrap) {
				HiddenTrap ht = (HiddenTrap) element;
				return ht;
			}
		}
		return null;
	}

	public List<GameElement> getElementList() {
		return elementList;
	}

		
}