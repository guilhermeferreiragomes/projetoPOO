package pt.iscte.poo.game;

public class Main {

	public static void main(String[] args) {
		GameEngine.getInstance().start();
	}
	
}
