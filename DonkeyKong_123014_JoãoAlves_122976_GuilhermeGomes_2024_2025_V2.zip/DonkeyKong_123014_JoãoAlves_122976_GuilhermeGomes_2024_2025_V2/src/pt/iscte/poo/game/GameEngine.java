package pt.iscte.poo.game;

import java.util.ArrayList;
import java.util.List;

import objects.Bomb;
import objects.GameElement;
import objects.Manel;
import java.awt.event.KeyEvent;
import pt.iscte.poo.gui.ImageGUI;
import pt.iscte.poo.observer.Observed;
import pt.iscte.poo.observer.Observer;
import pt.iscte.poo.utils.Direction;

public class GameEngine implements Observer {
	
	private static GameEngine instance;
	private Room currentRoom;
	private ImageGUI gui;
	private int lastTickProcessed = 0;
	private Manel manel;
	private String nickname;
	private ScoreBoard scoreBoard;

	public GameEngine() {
		gui = ImageGUI.getInstance();
		currentRoom = new Room();
		manel = currentRoom.getManel(); 
		scoreBoard = new ScoreBoard();
		gui.update();

	}
	

	public Room getCurrentRoom() {
		return currentRoom;
	}
	
	public static GameEngine getInstance() {
		if (instance == null) {
			instance = new GameEngine();
		}
		return instance;
	}


	@Override
	public void update(Observed source) {
		if (ImageGUI.getInstance().wasKeyPressed()) {
			int k = ImageGUI.getInstance().keyPressed();
			System.out.println("Keypressed " + k);
			if (Direction.isDirection(k)) {
				System.out.println("Direction! ");
				Direction direction = Direction.directionFor(k);
				currentRoom.manelStuff(direction);
			}
				if (k == KeyEvent.VK_B) {			
					currentRoom.getManel().dropBomb(new Bomb(currentRoom.getManel().getPosition()), currentRoom); // Método que larga a bomba
				}
			
		}
		int t = ImageGUI.getInstance().getTicks();
		while (lastTickProcessed < t) {
			processTick();
		}
		if (manel.getLife() <= 0) {
			currentRoom.getManel().setPosition(currentRoom.getHeroStartingPosition());
			manel.setLife(100);
			manel.setLives(manel.getLives() - 1);

			if(manel.getLives() == 0) {
				gui.showMessage("Perdeste as vidas todas", "", "images\\wasted.jpg");
				currentRoom.resetGame();
			}
		}
		
		gui.setStatusMessage("Boa sorte!" + "      VIDA: " + manel.getLife() + "      POWER: " + manel.getPower() + "      VIDAS: " + manel.getLives());

		if (currentRoom.win()) {
			int totalTicks = lastTickProcessed;
			scoreBoard.addScore(nickname, totalTicks);
			
			gui.showMessage("GANDA GAJO!", "Só em " + totalTicks + " ticks?\nTens de trabalhar melhor", "images\\Joao.jpg");
			scoreBoard.displayScores();
			System.exit(0); // Fecha o jogo
		}
		
		gui.update();
	}

	public ScoreBoard getScoreBoard() {
		return scoreBoard;
	}
	

	public String getNickname() {
		return nickname;
	}

	
	public void start() {
		gui = ImageGUI.getInstance();
		nickname = gui.askUser("NickName: ");
		while(nickname.equals("") || nickname.length() > 12){
			gui.showMessage("Erro", "Nickname inválido", null);
			nickname = gui.askUser("Nickname");
		}
		if(nickname.equals("admin")){
			scoreBoard.clearScores();
			System.out.println("Scores apagados");
		}
		gui.showMessage("Bem vindo!", "Deus esteja contigo, " + nickname, "images\\BadGuy.gif");
		gui.registerObserver(instance);
		manel.updateImg();
		currentRoom.enemyStuff();
		currentRoom.badMeat();
		gui.go();
		gui.update();

	}

private void processTick() {
	    currentRoom.enemyStuff(); // Atualiza inimigos
	    currentRoom.badMeat();    // Atualiza outros elementos

	    List<GameElement> elementsCopy = new ArrayList<>(currentRoom.getElementList());

	    for (GameElement element : elementsCopy) {
	        if (element instanceof Bomb) {
	            ((Bomb) element).checkExplosion(currentRoom); // Verifica se a bomba deve explodir
	        }
	    }

	    System.out.println("Tic Tac : " + lastTickProcessed);
	    lastTickProcessed++;
	}
	public int getLastTickProcessed() {
		return lastTickProcessed;
	}


	

}
