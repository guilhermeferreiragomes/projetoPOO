package pt.iscte.poo.game;

import java.io.Serializable;

public class Score implements Serializable {
    private String nickname;
    private int ticks;

    public Score(String nickname, int ticks) {
        this.nickname = nickname;
        this.ticks = ticks;
    }

    public String getNickname() {
        return nickname;
    }

    public int getTicks() {
        return ticks;
    }
}
